package com.kiranacademy.stringsorting;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
public class MobileController 
{
	@Autowired
	SessionFactory factory;
	
	@RequestMapping("getData")
	public List<Mobile> getData()
	{
		//List<Mobile> arrayList =factory.openSession().createCriteria(Mobile.class).list();
		
		List<Mobile> arrayList =factory.openSession().createQuery("from Mobile").list();
		System.out.println(arrayList);

        TreeSet<Mobile> treeset=new TreeSet<Mobile>(new SortOnPrice());
		
		for (Mobile mobile : arrayList) 
		{
			int price=mobile.price;
			
			if(price>=15 && price<=30)
				treeset.add(mobile);
		}
		
		System.out.println(treeset);
		
		ArrayList<Mobile> mobiles=new ArrayList<Mobile>(treeset);
		
		return arrayList ;


	}
}
