package com.kiranacademy.restapiex;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
	
	// localhost:8080/apicall
	
	@RequestMapping("apicall")
	public String apicall()
	{
		return "apicall";
	}

}
