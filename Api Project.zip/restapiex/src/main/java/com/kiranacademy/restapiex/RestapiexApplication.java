package com.kiranacademy.restapiex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiexApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiexApplication.class, args);
	}

}
