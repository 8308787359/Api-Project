package com.kiranacademy.restapiex;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/* 
To run this API, follow below steps:-
* 
* 1) localhost:8080/students - get
* 2) localhost:8080/student/1  - get
* 3) localhost:8080/student  - post ( add student object in arraylist )
* 4) localhost:8080/student/1  - delete 
* 5) localhost:8080/student - put (update)
* 
* 
*  JSON String format is :-
*  
*  {"rno":1,"marks":90}
*  
*  */
@RestController
@CrossOrigin("http://localhost:8080")
public class StudentController {
	
	@Autowired
	SessionFactory factory;
	
//	ArrayList<Student> arrayList = new ArrayList<Student>();
//	
//	StudentController()
//	{
//		Student student1 = new Student(1,90);
//		Student student2 = new Student(2,80);
//		
//		arrayList.add(student1);
//		arrayList.add(student2);
//	}
	
	@GetMapping("students")
	List<Student> allStudents()
	{

		Session session=factory.openSession();
		
		List<Student> arrayList= session.createCriteria(Student.class).list();
		
		return arrayList;
		
	}

	//@PathVariable assign value of path vaiable to local variable
	//localhost:8085/student/1
	@GetMapping("student/{rno}")
	public Student getStudent(@PathVariable int rno)
	{
		
       Session session=factory.openSession();
		
		Student student=session.get(Student.class,rno);
		
		return student;
		//System.out.println(rno);
		
//		for (Student student : arrayList)
//		{
//			if(student.rno==rno)
//				return student;
//		}
		
	}
     
	// {"rno":3,"marks":50}
	@PostMapping("student")
	public List<Student>  addStudent(@RequestBody Student student)
	{
		Session session=factory.openSession();
		
		
		Transaction tx = session.beginTransaction();
		
			session.save(student);
		
		tx.commit();
		
		List<Student> list=allStudents();
		
		return list;
		
	}
//    public ArrayList addStudent(@RequestBody Student student)
//    {
//    	arrayList.add(student);
//    	return arrayList;
//    }
	
	
	@DeleteMapping("student/{rno}")
	public List<Student> deleteStudent(@PathVariable int rno) 
	{
		
	    Session session=factory.openSession();
		
		Student student=session.load(Student.class,rno);
		
		
		Transaction tx = session.beginTransaction();
	
			session.delete(student);
			
		tx.commit();
		

		List<Student> list=allStudents();
		
		return list;	
		
	}
//	public String deleteStudent(@PathVariable int rno)
//	{
//		Student deleteStudent=null; // we declared object
//		
//		// [(rno=1,marks=90),(rno=2,marks=80),(rno=3,marks=40)]	ArrayList
//		for(Student student : arrayList)
//		{
//			if(student.rno==rno)
//				arrayList.remove(student);
//			//deleteStudent=student;//Instead of above
//			//break;
//			// concurrentModification exception may occur if we use ArrayList's remove here .
//		}
//		return "record deleted";

	
	// {"rno"2,"marks":35} , using this JSON String , @RequestBody will create Student object clientStudent.
	
		// for updation , use @PutMapping
	@PutMapping("student")
	public List<Student> updateStudent(@RequestBody Student clientStudent) 
	{

		Session session=factory.openSession();
		
		
	    Transaction tx = session.beginTransaction();
		
			session.saveOrUpdate(clientStudent);
					
		tx.commit();
		

		List<Student> list=allStudents();
		
		return list;		 

//	public ArrayList updateStudent(@RequestBody Student clientStudent)
//	{
//		
//		// [(rno=1,marks=90),(rno=2,marks=35),(rno=3,marks=40)]	ArrayList
//		for (Student student : arrayList)
//		{
//			if(student.rno==clientStudent.rno)
//			{
//				student.setMarks(clientStudent.getMarks());
//			}
//		}
//		return arrayList;
	}

}// All task Done Succesfully,,,All is well
