package com.kiranacademy.apiex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
@EntityScan("com")
public class RestApiApplication3 {

	public static void main(String[] args) {
		SpringApplication.run(RestApiApplication3.class, args);

	}

}
